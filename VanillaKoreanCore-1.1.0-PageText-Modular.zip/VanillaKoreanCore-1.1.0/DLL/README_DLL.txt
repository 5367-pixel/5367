3D NPC 이름표 DLL 설치
=====================

1. VanillaKoreanCore.dll과 VanillaKoreanCore_NPC.txt를 WoW.exe 폴더에 복사합니다.
2. 사용하는 DLL 로더의 dlls.txt에 다음 한 줄을 추가합니다.
   VanillaKoreanCore.dll
3. CNFixEnglish.dll은 같은 이름표 함수를 후킹하므로 동시에 로드하지 않습니다.
4. 게임을 완전히 종료한 뒤 다시 실행합니다.

DLL은 WoW 1.12.1 build 5875 전용입니다.
애드온만 사용하면 툴팁은 번역되지만 머리 위 3D 이름표는 바뀌지 않습니다.
