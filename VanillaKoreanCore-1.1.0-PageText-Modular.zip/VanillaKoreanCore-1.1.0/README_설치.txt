VanillaKoreanCore 1.1.0 통합 한글화
================================

애드온 설치
-----------
Interface 폴더를 WoW 설치 폴더에 덮어씁니다.
최종 경로는 Interface\AddOns\VanillaKoreanCore\VanillaKoreanCore.toc 입니다.
기존의 별도 구버전 NPC 이름 애드온 폴더는 삭제하거나 비활성화하세요.

3D 이름표 DLL 설치
------------------
DLL 폴더의 VanillaKoreanCore.dll과 VanillaKoreanCore_NPC.txt를 WoW.exe 폴더에 넣습니다.
dlls.txt에 VanillaKoreanCore.dll 한 줄을 추가합니다.
CNFixEnglish.dll과는 같은 이름표 주소를 사용하므로 동시에 로드하지 마세요.

게임을 완전히 종료한 뒤 다시 실행해야 DLL 교체가 적용됩니다.

NPC 툴팁 명령어
---------------
/vkc on
/vkc off
/vkc english on
/vkc english off

책·쪽지 한글화 명령어
---------------------
/vkcpage on
/vkcpage off

PageText 모듈은 책, 편지, 쪽지, 일지, 석판처럼 읽기 창에 표시되는
본문을 한글로 교체합니다. 기존 한국어/영어 원문 전환이 영어로 설정된
동안에는 영문 원문을 그대로 표시합니다.
